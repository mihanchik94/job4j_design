package ru.job4j;

public class Checkstyle {
    public static void main(String[] args) {
        System.out.println("Hello world");
    }
}
