package ru.job4j;

public class StudentInfo {
    public static void main(String[] args) {
        System.out.println("Michael Ponomarev");
        System.out.println("01.05.1994");
    }
}
