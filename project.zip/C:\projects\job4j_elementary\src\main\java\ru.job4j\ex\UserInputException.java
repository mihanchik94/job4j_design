package ru.job4j.ex;

public class UserInputException extends Exception {
    public UserInputException(String message) {
        super(message);
    }
}
