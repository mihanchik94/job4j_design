package ru.job4j.oop;

public class Ball {
    public void tryRun(Hare hare) {

    }
    public void tryRun(Volk wolf) {

    }

    public void notTryRun(Fox fox) {

    }
}
