package ru.job4j.oop;

public class Volk {
    public void tryEat(Ball ball) {

    }
}
