package ru.job4j.poly;

public interface Transport {

    void go();

    void passengers(int people);

    float price(float fuel);
}
