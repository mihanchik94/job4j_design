/*
package ru.job4j.profession;

public class Builder extends Engineer {
    private String licence;

    public String getLicence() {
    }

    public void building() {
    }
}
*/
