/*
package ru.job4j.profession;

public class Dentist extends Doctor {
    private Patient[] patientList;
    private boolean remove;
    private boolean implantation;

    public Patient[] getPatientList() {
    }

    public boolean getRemove() {
    }

    public boolean getImplantation() {
    }

    public int dentalTreatment() {
    }
}
*/
