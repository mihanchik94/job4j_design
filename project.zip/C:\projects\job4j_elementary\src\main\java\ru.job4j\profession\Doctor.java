/*
package ru.job4j.profession;

public class Doctor extends Profession {
    public String diagnosis(Patient patient) {
    }
}
*/
