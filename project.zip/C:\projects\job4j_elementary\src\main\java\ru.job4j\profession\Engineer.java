/*
package ru.job4j.profession;

public class Engineer extends Profession {
    private Project[] projectList;

    public Project[] getProjectList() {
    }
}
*/
