/*
package ru.job4j.profession;

public class Patient {
    private String name;
    private String surname;
    private String birthday;
    private long policy;

    public String getName() {
    }

    public String getSurname() {
    }

    public String getBirthday() {
    }

    public long getPolicy() {
    }
}
*/
