/*
package ru.job4j.profession;

public class Profession {
    private String name;
    private String surname;
    private String education;
    private String birthday;
    private String experience;
    private int salary;

    public String getName() {
    }

    public String getSurname() {
    }

    public String getEducation() {
    }

    public String getBirthday() {
    }

    public String getExperience() {
    }

    public int getSalary() {
    }
}
*/
