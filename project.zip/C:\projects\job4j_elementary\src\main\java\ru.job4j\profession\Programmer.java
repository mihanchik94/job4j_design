/*
package ru.job4j.profession;

public class Programmer extends Engineer {
    private boolean english;

    public boolean getEnglish() {
    }

    public void createProgram() {
    }
}
*/
