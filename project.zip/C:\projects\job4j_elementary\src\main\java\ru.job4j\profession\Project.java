/*
package ru.job4j.profession;

public class Project {
    private String name;
    private int number;
    private String startDate;
    private String finishDate;

    public String getName() {
    }

    public int getNumber() {
    }

    public String getStartDate() {
    }

    public String getFinishDate() {
    }
}
*/
