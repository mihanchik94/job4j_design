/*
package ru.job4j.profession;

public class Surgeon extends Doctor {
    private Patient[] patientList;

    public Patient[] getPatientList() {
    }

    public String makingOperation(Patient patient) {
    }
}
*/
