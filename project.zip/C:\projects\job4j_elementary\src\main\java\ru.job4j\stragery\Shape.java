package ru.job4j.stragery;

public interface Shape {
    String draw();
}
