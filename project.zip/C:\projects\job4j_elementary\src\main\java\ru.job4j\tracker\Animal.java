package ru.job4j.tracker;

public class Animal {
    public Animal() {
        super();
        System.out.println("Animal");
    }
}
