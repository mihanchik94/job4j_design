/*
package ru.job4j.tracker;

public class Bug extends Item {
}
*/
