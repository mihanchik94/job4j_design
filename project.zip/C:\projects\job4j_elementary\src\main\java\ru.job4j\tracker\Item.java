//package ru.job4j.tracker;
//
//public class Item {
//    private String id;
//    private String name;
//
//    public Item() {
//    }
//
//    public Item(String id) {
//    }
//
//    public Item(String name) {
//    }
//
//    public Item(String id, String name) {
//    }
//
//}
